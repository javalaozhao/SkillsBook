#!/usr/bin/env python3
"""
Obsidian 文件自动整理工具
自动扫描 Obsidian 仓库，按主题分类散落的文件
"""

import os
import re
import shutil
from pathlib import Path
from collections import defaultdict

# 文件分类规则（关键词映射）
CATEGORIES = {
    "AI相关": [
        "AI", "Claude", "DeepSeek", "GPT", "Agent", "RAG", "LLM",
        "模型", "智能", "大语言", "机器学习", "神经网络", "提示词",
        "Vibe", "Coding", "OpenCode", "生成式AI", "推理"
    ],
    "提示词仓库": [
        "prompt", "Prompt", "提示词", "模板", "工程", "生成",
        "prompt", "框架", "指令", "引导"
    ],
    "产品经理": [
        "产品", "PRD", "运营", "策略", "用户", "需求",
        "商业", "价值", "增长", "营销", "私域", "小红书"
    ],
    "技术开发": [
        "前端", "后端", "Web3", "编程", "代码", "开发",
        "Tailwind", "CSS", "JavaScript", "Python", "API",
        "网站", "工具", "组件", "页面"
    ],
    "methodology": [
        "认知", "框架", "方法", "思维", "模型", "分析",
        "系统", "逻辑", "思考", "学习", "素养"
    ],
    "个人发展": [
        "简历", "面试", "职业", "成长", "规划", "自由",
        "搞钱", "计划", "目标", "习惯"
    ],
    "数据分析": [
        "SEO", "数据", "分析", "指标", "统计", "搜索",
        "关键词", "流量", "优化"
    ],
    "读书笔记": [
        "读书", "笔记", "阅读", "书籍", "分享"
    ]
}

# 保留的文件夹（不处理）
PROTECTED_FOLDERS = {
    ".obsidian", ".smart-env", ".smtcmp_json_db",
    "attachments", "日记", "新枝", "紫薇星盘", "模板仓库"
}

# 图片文件扩展名
IMAGE_EXTENSIONS = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".heic", ".svg"
}


def scan_files(target_dir):
    """扫描目标目录中的散落文件"""
    target_path = Path(target_dir)

    if not target_path.exists():
        print(f"错误：目录不存在 - {target_dir}")
        return None

    # 获取根目录下的所有文件
    files = []
    for item in target_path.iterdir():
        if item.is_file():
            # 跳过隐藏文件和系统文件
            if not item.name.startswith('.'):
                files.append(item)

    return files


def categorize_file(filename):
    """根据文件名判断分类"""
    filename_lower = filename.lower()

    for category, keywords in CATEGORIES.items():
        for keyword in keywords:
            if keyword.lower() in filename_lower:
                return category

    return None


def create_categories(target_dir):
    """创建分类文件夹"""
    target_path = Path(target_dir)

    for category in CATEGORIES.keys():
        category_dir = target_path / category
        if not category_dir.exists():
            category_dir.mkdir(parents=True, exist_ok=True)
            print(f"创建文件夹: {category}")


def move_files(files, target_dir, dry_run=False):
    """移动文件到对应分类"""
    target_path = Path(target_dir)

    # 统计移动的文件
    moved_stats = defaultdict(int)
    uncategorized = []

    for file in files:
        category = categorize_file(file.name)

        if category:
            dest_dir = target_path / category
            dest_path = dest_dir / file.name

            # 检查目标文件是否已存在
            if dest_path.exists():
                print(f"跳过（已存在）: {file.name}")
                continue

            if not dry_run:
                shutil.move(str(file), str(dest_path))

            moved_stats[category] += 1
            print(f"移动: {file.name} -> {category}/")
        else:
            uncategorized.append(file.name)

    return moved_stats, uncategorized


def move_images(target_dir, dry_run=False):
    """移动图片文件到 attachments 文件夹"""
    target_path = Path(target_dir)
    attachments_dir = target_path / "attachments"

    if not attachments_dir.exists():
        attachments_dir.mkdir(parents=True, exist_ok=True)

    moved_count = 0

    for item in target_path.iterdir():
        if item.is_file() and item.suffix.lower() in IMAGE_EXTENSIONS:
            dest_path = attachments_dir / item.name

            if dest_path.exists():
                print(f"跳过图片（已存在）: {item.name}")
                continue

            if not dry_run:
                shutil.move(str(item), str(dest_path))

            moved_count += 1
            print(f"移动图片: {item.name}")

    return moved_count


def generate_report(target_dir):
    """生成整理报告"""
    target_path = Path(target_dir)

    print("\n" + "="*50)
    print("📊 整理报告")
    print("="*50)

    # 统计各文件夹文件数
    for category in sorted(CATEGORIES.keys()):
        category_dir = target_path / category
        if category_dir.exists():
            count = len(list(category_dir.glob('*')))
            print(f"{category}: {count} 个文件")

    # 统计图片
    attachments_dir = target_path / "attachments"
    if attachments_dir.exists():
        count = len(list(attachments_dir.glob('*')))
        print(f"attachments: {count} 个文件")

    print("="*50)


def main(target_dir, dry_run=False):
    """主函数"""
    print(f"🔍 扫描目录: {target_dir}")
    print()

    # 扫描文件
    files = scan_files(target_dir)
    if not files:
        print("未找到需要整理的文件")
        return

    print(f"找到 {len(files)} 个文件")
    print()

    # 创建分类文件夹
    print("创建分类文件夹...")
    create_categories(target_dir)
    print()

    # 移动文件
    print("开始整理文件...")
    moved_stats, uncategorized = move_files(files, target_dir, dry_run)
    print()

    # 移动图片
    print("整理图片文件...")
    moved_images = move_images(target_dir, dry_run)
    print()

    # 生成报告
    generate_report(target_dir)

    # 显示未分类的文件
    if uncategorized:
        print(f"\n⚠️  未分类的文件 ({len(uncategorized)} 个):")
        for filename in uncategorized[:10]:
            print(f"  - {filename}")
        if len(uncategorized) > 10:
            print(f"  ... 还有 {len(uncategorized) - 10} 个文件")


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("用法: python obsidian_organizer.py <Obsidian目录路径> [--dry-run]")
        sys.exit(1)

    target_dir = sys.argv[1]
    dry_run = "--dry-run" in sys.argv

    if dry_run:
        print("⚠️  预览模式（不会实际移动文件）\n")

    main(target_dir, dry_run)
