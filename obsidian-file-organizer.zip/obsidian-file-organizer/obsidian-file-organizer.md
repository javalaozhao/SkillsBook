# Obsidian 文件整理专家

自动整理 Obsidian 仓库中的散落文件，按主题分类到不同文件夹中。

## 功能描述

1. 扫描 Obsidian 仓库根目录的散落文件
2. 根据文件名和内容进行智能分类
3. 创建分类文件夹（如：AI相关、产品经理、技术开发等）
4. 移动文件到对应文件夹
5. 整理图片和附件到 attachments 文件夹
6. 保留现有文件夹结构不变

## 工作流程

### 第一步：分析文件结构
```bash
# 列出目标目录的所有文件
ls -la "/path/to/Obsidian"
```

### 第二步：分类文件
根据文件名关键词进行分类：
- **AI相关**：AI、大模型、Claude、DeepSeek、Agent、RAG、LLM
- **提示词仓库**：prompt、提示词、模板、工程
- **产品经理**：产品、PRD、运营、策略、用户
- **技术开发**：前端、后端、Web3、编程、代码
- **思维模型/方法论**：认知、框架、方法、思维
- **个人发展**：简历、面试、职业、成长
- **数据分析**：SEO、数据、分析、指标

### 第三步：创建文件夹
```bash
mkdir -p "AI相关" "产品经理" "技术开发" "个人发展" "数据分析"
```

### 第四步：移动文件
```bash
# 使用 find 命令处理特殊字符
find . -maxdepth 1 -name "*关键词*" -exec mv {} 目标文件夹/ \;
```

### 第五步：整理图片
```bash
mv *.png attachments/
mv *.heic attachments/
```

### 第六步：生成报告
统计各文件夹的文件数量，输出整理报告。

## 分类规则详表

| 文件夹 | 关键词 |
|--------|--------|
| AI相关 | AI, Claude, DeepSeek, GPT, Agent, RAG, LLM, 模型, 智能 |
| 提示词仓库 | prompt, 提示词, 模板, 工程, 生成 |
| 产品经理 | 产品, PRD, 运营, 策略, 用户, 需求 |
| 技术开发 | 前端, 后端, Web3, 编程, 代码, 开发 |
| methodology | 认知, 框架, 方法, 思维, 模型 |
| 个人发展 | 简历, 面试, 职业, 成长, 规划 |
| 数据分析 | SEO, 数据, 分析, 指标, 统计 |

## 使用示例

**用户输入：**
```
帮我整理一下我的 Obsidian 仓库，文件在 ~/Documents/Obsidian
```

**技能执行：**
1. 扫描目录结构
2. 分析散落文件
3. 创建分类文件夹
4. 移动文件
5. 输出整理报告

## 注意事项

1. 保留 `.obsidian` 系统文件夹
2. 不修改用户已创建的文件夹
3. 处理文件名中的特殊字符（中文引号、空格等）
4. 使用 `find` 命令处理特殊文件名
5. 移动前确认目标文件夹存在

## 实现代码示例

```bash
#!/bin/bash
TARGET_DIR="$1"
cd "$TARGET_DIR"

# 创建分类文件夹
mkdir -p "AI相关" "产品经理" "技术开发" "个人发展" "数据分析"

# 移动 AI 相关文件
for keyword in "AI" "Claude" "DeepSeek" "Agent" "RAG"; do
  find . -maxdepth 1 -name "*${keyword}*" -type f -exec mv {} "AI相关/" \;
done

# 移动图片
mv *.png attachments/ 2>/dev/null
mv *.heic attachments/ 2>/dev/null

# 生成报告
echo "整理完成！"
for dir in */; do
  count=$(find "$dir" -type f | wc -l)
  echo "$dir: $count 个文件"
done
```
