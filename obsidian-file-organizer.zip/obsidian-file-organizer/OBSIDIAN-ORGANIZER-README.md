# Obsidian 文件整理专家 - 使用指南

## 📖 技能说明

这个技能可以自动整理你的 Obsidian 仓库，将散落的文件按主题分类到不同文件夹中。

## 🚀 快速开始

### 方式一：直接运行 Python 脚本

```bash
# 预览模式（不会实际移动文件）
python3 .obsidian/scripts/obsidian_organizer.py /path/to/Obsidian --dry-run

# 正式执行
python3 .obsidian/scripts/obsidian_organizer.py /path/to/Obsidian
```

### 方式二：让 Claude AI 执行

直接对 Claude 说：
```
帮我整理一下我的 Obsidian 仓库，路径是 ~/Documents/Obsidian
```

Claude 会自动：
1. 扫描散落文件
2. 分析文件名和内容
3. 创建分类文件夹
4. 移动文件到对应位置
5. 整理图片和附件
6. 生成整理报告

## 📂 分类规则

| 文件夹 | 关键词 |
|--------|--------|
| **AI相关** | AI, Claude, DeepSeek, GPT, Agent, RAG, LLM, 模型, 智能 |
| **提示词仓库** | prompt, 提示词, 模板, 工程, 生成 |
| **产品经理** | 产品, PRD, 运营, 策略, 用户, 需求 |
| **技术开发** | 前端, 后端, Web3, 编程, 代码, 开发 |
| **methodology** | 认知, 框架, 方法, 思维, 模型 |
| **个人发展** | 简历, 面试, 职业, 成长, 规划 |
| **数据分析** | SEO, 数据, 分析, 指标, 统计 |
| **读书笔记** | 读书, 笔记, 阅读, 书籍 |

## ⚙️ 自定义分类

编辑 `.obsidian/scripts/obsidian_organizer.py` 中的 `CATEGORIES` 字典来添加自定义分类：

```python
CATEGORIES = {
    "我的分类": [
        "关键词1", "关键词2", "关键词3"
    ],
    # ... 添加更多分类
}
```

## 📋 整理报告示例

```
==================================================
📊 整理报告
==================================================
AI相关: 24 个文件
产品经理: 15 个文件
技术开发: 12 个文件
methodology: 18 个文件
提示词仓库: 83 个文件
attachments: 95 个文件
==================================================
```

## ⚠️ 注意事项

1. **保留的文件夹**：以下文件夹不会被修改
   - `.obsidian` - Obsidian 配置
   - `attachments` - 附件文件夹
   - `日记` - 日记文件夹
   - 用户自定义的其他文件夹

2. **特殊字符处理**：脚本会自动处理文件名中的特殊字符

3. **备份建议**：首次使用前建议备份仓库

4. **预览模式**：使用 `--dry-run` 参数可以预览整理效果

## 📁 文件位置

- 技能文档：`.obsidian/skills/obsidian-file-organizer.md`
- Python 脚本：`.obsidian/scripts/obsidian_organizer.py`
- 使用说明：`.obsidian/skills/OBSIDIAN-ORGANIZER-README.md`
